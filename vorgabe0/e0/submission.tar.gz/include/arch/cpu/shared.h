#ifndef SHARED_H
#define SHARED_H

extern int print_register_dump;

#endif
