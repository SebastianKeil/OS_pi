#ifndef CHECK_INTERRUPTS_H
#define CHECK_INTERRUPTS_H

void check_for_interrupts(char, unsigned int regs[]);

#endif
