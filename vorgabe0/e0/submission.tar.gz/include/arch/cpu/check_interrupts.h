#ifndef CHECK_INTERRUPTS_H
#define CHECK_INTERRUPTS_H

//int print_register_dump;
//unsigned char receive_buffer;

void check_interrupts(unsigned char);

#endif
