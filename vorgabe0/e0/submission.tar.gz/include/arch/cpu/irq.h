#include <lib/utilities.h> 

#ifndef IRQ_H
#define IRQ_H

void irq(unsigned int regs[35]);

#endif
