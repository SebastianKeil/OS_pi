#ifndef SYS_TIMER_H
#define SYS_TIMER_H

void set_timing(int time);
void print_timer_setting(void);
void reset_sys_timer(void);

#endif
