#ifndef _UNTERPROGRAMM_H
#define _UNTERPROGRAMM_H


void masterprogramm(unsigned char *void_char);

#endif
