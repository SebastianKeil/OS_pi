#ifndef _MASTERPROGRAMM_H
#define _MASTERPROGRAMM_H

void create_masterprogram_thread();
void masterprogramm(unsigned char *void_char);

#endif
