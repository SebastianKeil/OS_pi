#ifndef _REGCHECK_H_
#define _REGCHECK_H_

void register_checker(void);

#endif//_REGCHECK_H_