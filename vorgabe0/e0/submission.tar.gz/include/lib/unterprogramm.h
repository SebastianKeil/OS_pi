#ifndef _UNTERPROGRAMM_H
#define _UNTERPROGRAMM_H


void sleep(unsigned int ticks);
void print_answer(unsigned char *input);
void end_this_thread(void);
void unterprogramm(unsigned char *input);

#endif
