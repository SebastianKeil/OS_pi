#ifndef _UNTERPROGRAMM_H
#define _UNTERPROGRAMM_H

void sleep(unsigned int ticks);
void print_answer(unsigned char print_char);
void unterprogramm(void);

#endif
