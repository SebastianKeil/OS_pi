#ifndef _KMEM_CPY_H
#define _KMEM_CPY_H

void kmemcpy(void *dest, const void * src, unsigned int n);

#endif
