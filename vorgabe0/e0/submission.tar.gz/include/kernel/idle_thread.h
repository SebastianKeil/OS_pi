#ifndef IDLE_THREAD_H
#define IDLE_THREAD_H

//void sleeps(int ticks);
void idle_thread(void);

#endif
